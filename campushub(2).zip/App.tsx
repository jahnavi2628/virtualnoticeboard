
import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { User, Notice } from './types';
import { MOCK_USERS, MOCK_NOTICES } from './constants';
import { View } from './components/Sidebar';

const App: React.FC = () => {
    const [currentUser, setCurrentUser] = useState<User | null>(MOCK_USERS[0]);
    const [activeView, setActiveView] = useState<View>('dashboard');
    const [notices, setNotices] = useState<Notice[]>(MOCK_NOTICES);

    const handleCreateNotice = (newNoticeData: Omit<Notice, 'id' | 'date' | 'isPinned'>) => {
        const newNotice: Notice = {
            id: `n${notices.length + 1}`,
            date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
            isPinned: false,
            ...newNoticeData,
        };
        setNotices(prevNotices => [newNotice, ...prevNotices]);
    };

    return (
        <Layout 
            currentUser={currentUser}
            setCurrentUser={setCurrentUser}
            activeView={activeView}
            setActiveView={setActiveView}
            notices={notices}
            onCreateNotice={handleCreateNotice}
        />
    );
};

export default App;
