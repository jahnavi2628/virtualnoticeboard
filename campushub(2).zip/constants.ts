import {
    User, UserRole, Notice, NoticeCategory, Message, ChatChannel, Branch,
    QuickLink, Job, Achievement, GalleryImage, Club, Playlist, Track,
    CareerResource, CareerPath
} from './types';

export const MOCK_USERS: User[] = [
    { id: 'u1', name: 'Admin User', avatarUrl: 'https://i.pravatar.cc/150?u=admin', role: UserRole.ADMIN },
    { id: 'u2', name: 'Priya Sharma', avatarUrl: 'https://i.pravatar.cc/150?u=priya', role: UserRole.STUDENT },
    { id: 'u3', name: 'Raj Kumar', avatarUrl: 'https://i.pravatar.cc/150?u=raj', role: UserRole.CLUB_MEMBER, club: 'Tech Club' },
    { id: 'u4', name: 'Anita Desai', avatarUrl: 'https://i.pravatar.cc/150?u=anita', role: UserRole.CLUB_MEMBER, club: 'Literary Club' },
];

export const MOCK_NOTICES: Notice[] = [
    {
        id: 'n1',
        title: 'Campus Placement Drive: InfoSys',
        content: 'InfoSys is visiting our campus for a recruitment drive for final year students. All eligible students are requested to register on the portal by EOD Friday. The drive will include an aptitude test, technical round, and HR interview.',
        author: 'Placement Cell',
        date: 'May 18, 2024',
        category: NoticeCategory.PLACEMENTS,
        isPinned: true,
        imageUrl: 'https://images.unsplash.com/photo-1556761175-b413da4b2489?q=80&w=1974&auto=format&fit=crop',
        organizers: [{ name: 'Placement Cell', avatarUrl: 'https://i.pravatar.cc/150?u=placement' }]
    },
    {
        id: 'n2',
        title: 'Tech Club Recruitment: Web & App Devs',
        content: 'The Tech Club is looking for passionate developers to join our web and app development teams for the upcoming semester projects. Showcase your skills and build amazing things with us!',
        author: 'Tech Club',
        date: 'May 17, 2024',
        category: NoticeCategory.CLUB,
        isPinned: true,
        recruitment: {
            title: 'Hiring Developers',
            description: 'Join our team to work on exciting projects.',
            roles: ['Frontend Dev', 'Backend Dev', 'UI/UX Designer', 'Mobile Dev']
        }
    },
    {
        id: 'n3',
        title: 'Annual Sports Meet "Velocity 2024"',
        content: 'Get ready for the most awaited event of the year! The annual sports meet is back. Registrations for track events, football, and basketball are now open.',
        author: 'Sports Committee',
        date: 'May 15, 2024',
        category: NoticeCategory.SPORTS,
        isPinned: false,
        imageUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?q=80&w=1935&auto=format&fit=crop'
    },
    {
        id: 'n4',
        title: 'Results for Semester VI Declared',
        content: 'The results for the 6th-semester examinations have been published on the university portal. Students can log in to view their grade cards.',
        author: 'Academics Office',
        date: 'May 12, 2024',
        category: NoticeCategory.ACADEMICS,
        isPinned: false,
    },
];

export const MOCK_MESSAGES: Message[] = [
    { id: 'm1', sender: 'Priya Sharma', avatarUrl: 'https://i.pravatar.cc/150?u=priya', message: 'Has anyone started on the DSA assignment?', timestamp: '10:30 AM', channel: ChatChannel.GENERAL },
    { id: 'm2', sender: 'Raj Kumar', avatarUrl: 'https://i.pravatar.cc/150?u=raj', message: 'Yeah, the first two problems are tricky. We should discuss them.', timestamp: '10:32 AM', channel: ChatChannel.GENERAL },
    { id: 'm3', sender: 'Admin User', avatarUrl: 'https://i.pravatar.cc/150?u=admin', message: 'Reminder: The library will be closed this Saturday for maintenance.', timestamp: '11:00 AM', channel: ChatChannel.ANNOUNCEMENTS },
    { id: 'm4', sender: 'Raj Kumar', avatarUrl: 'https://i.pravatar.cc/150?u=raj', message: 'Pushing the latest changes for the auth module now.', timestamp: '1:15 PM', channel: ChatChannel.PROJECTS },
];

const CSE_SEMS = [
    { id: 's1', name: 'Semester 1', subjects: [{ name: 'Physics', credits: 4 }, { name: 'Maths I', credits: 4 }, { name: 'Chemistry', credits: 3 }] },
    { id: 's2', name: 'Semester 2', subjects: [{ name: 'Data Structures', credits: 4 }, { name: 'Maths II', credits: 4 }, { name: 'OOPs', credits: 3 }] },
];
const ECE_SEMS = [
    { id: 's1', name: 'Semester 1', subjects: [{ name: 'Basic Electronics', credits: 4 }, { name: 'Maths I', credits: 4 }, { name: 'Communication', credits: 3 }] },
];

export const MOCK_BRANCHES: Branch[] = [
    { name: 'Computer Science', semesters: CSE_SEMS },
    { name: 'Electronics', semesters: ECE_SEMS },
    { name: 'Mechanical', semesters: [] },
];

export const MOCK_QUICK_LINKS: QuickLink[] = [
    { name: 'University Examination Portal', url: '#' },
    { name: 'Official College Website', url: '#' },
    { name: 'Library E-Resources', url: '#' },
    { name: 'Student Grievance Cell', url: '#' },
];

export const MOCK_JOBS: Job[] = [
    { id: 'j1', title: 'Software Engineer', company: 'Google', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg', location: 'Bangalore, India', salary: '₹25-30 LPA', type: 'Full-time', description: 'Seeking a skilled software engineer to build high-performance applications.' },
    { id: 'j2', title: 'Product Design Intern', company: 'Microsoft', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/44/Microsoft_logo.svg', location: 'Hyderabad, India', salary: '₹80k/month stipend', type: 'Internship', description: 'Join our design team to create intuitive user experiences for millions.' },
    { id: 'j3', title: 'Data Scientist', company: 'Amazon', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg', location: 'Remote', salary: '₹22-28 LPA', type: 'Full-time', description: 'Analyze large datasets to extract meaningful insights and drive business decisions.' },
];

export const MOCK_ACHIEVEMENTS: Achievement[] = [
    { id: 'a1', studentName: 'Rohan Verma', avatarUrl: 'https://i.pravatar.cc/150?u=rohan', achievement: '1st Place Winner', competition: 'Smart India Hackathon 2024', date: 'April 20, 2024' },
    { id: 'a2', studentName: 'Meera Patel', avatarUrl: 'https://i.pravatar.cc/150?u=meera', achievement: 'Best Speaker Award', competition: 'National Debating Championship', date: 'March 15, 2024' },
];

export const MOCK_GALLERY_IMAGES: GalleryImage[] = [
    { id: 'g1', src: 'https://images.unsplash.com/photo-1562774053-701939374585', alt: 'University main building on a sunny day' },
    { id: 'g2', src: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f', alt: 'Students during a convocation ceremony' },
    { id: 'g3', src: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1', alt: 'A group of students studying in the library' },
    { id: 'g4', src: 'https://images.unsplash.com/photo-1571260899059-8a2779a734f8', alt: 'Students participating in a sports event' },
];

export const MOCK_CLUBS: Club[] = [
    { id: 'c1', name: 'Tech Club', description: 'For the coders, builders, and innovators.', longDescription: 'The Tech Club is a community of students passionate about technology. We organize workshops, hackathons, and speaker sessions to foster a culture of learning and building.', logoUrl: 'https://i.pravatar.cc/150?u=techclub', bannerUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726a', category: 'Technical', members: [{ name: 'Raj Kumar', role: 'President', avatarUrl: 'https://i.pravatar.cc/150?u=raj' }], events: [{ id: 'e1', title: 'Intro to Git & GitHub', date: 'May 25', description: 'Learn version control basics.' }] },
    { id: 'c2', name: 'Literary Club', description: 'Celebrating the world of words and stories.', longDescription: 'From poetry slams to book discussions, the Literary Club is the perfect place for bookworms and creative writers to connect and share their passion.', logoUrl: 'https://i.pravatar.cc/150?u=litclub', bannerUrl: 'https://images.unsplash.com/photo-1455390582262-044cdead277a', category: 'Non-Technical', members: [{ name: 'Anita Desai', role: 'President', avatarUrl: 'https://i.pravatar.cc/150?u=anita' }], events: [] },
    { id: 'c3', name: 'Photography Club', description: 'Capture moments, tell stories.', longDescription: 'Join us to explore the art of photography. We conduct photo walks, workshops on editing, and annual exhibitions.', logoUrl: 'https://i.pravatar.cc/150?u=photoclub', bannerUrl: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32', category: 'Cultural', members: [], events: [] },
];

export const MOCK_TRACKS: Track[] = [
    { id: 't1', title: 'Sunset Drive', artist: 'Infraction', album: 'Future Bass', duration: '3:45', coverArt: 'https://images.unsplash.com/photo-1619983081563-436f63e02242' },
    { id: 't2', title: 'Lift Off', artist: 'Cosmo Sheldrake', album: 'The Much Much How How', duration: '4:12', coverArt: 'https://images.unsplash.com/photo-1506157786151-b8491531f063' },
];

export const MOCK_PLAYLISTS: Playlist[] = [
    { id: 'p1', name: 'Study Beats', coverArt: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d', trackCount: 42 },
    { id: 'p2', name: 'Workout Fuel', coverArt: 'https://images.unsplash.com/photo-1549499232-a735c825a917', trackCount: 28 },
];

export const MOCK_CAREER_RESOURCES: CareerResource[] = [
    { id: 'cr1', title: 'How to Build a Killer Resume', type: 'Article', author: 'Jane Doe, Career Expert', summary: 'Learn the dos and don\'ts of resume writing to land your dream job.', thumbnailUrl: 'https://images.unsplash.com/photo-1542314831-068cd1dbb5b9', url: '#' },
    { id: 'cr2', title: 'Mastering Technical Interviews', type: 'Video', author: 'TechLead', summary: 'A comprehensive guide to cracking technical interviews at top tech companies.', thumbnailUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71', url: '#' },
];

export const MOCK_CAREER_PATHS: CareerPath[] = [
    { id: 'cp1', title: 'Frontend Development', description: 'Build beautiful and interactive user interfaces for websites and web applications.', skills: ['HTML', 'CSS', 'JavaScript', 'React', 'UI/UX'], relatedRoles: ['UI Engineer', 'Web Developer'] },
    { id: 'cp2', title: 'Data Science', description: 'Use data to solve complex problems and make predictions using statistical models and machine learning.', skills: ['Python', 'SQL', 'Statistics', 'Machine Learning'], relatedRoles: ['Data Analyst', 'ML Engineer'] },
];
