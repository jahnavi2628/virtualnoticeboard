
import React, { useState } from 'react';
import { MOCK_PLAYLISTS, MOCK_TRACKS } from '../constants';
import { RadioPlayer } from './RadioPlayer';
import { PlaylistCard } from './PlaylistCard';
import { UploadTrackModal } from './UploadTrackModal';
import { User, UserRole } from '../types';
import { Track } from '../types';
import { UploadIcon } from './icons/UploadIcon';


interface RadioCellProps {
    currentUser: User | null;
}

export const RadioCell: React.FC<RadioCellProps> = ({ currentUser }) => {
    const [selectedTrack, setSelectedTrack] = useState(MOCK_TRACKS[0]);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const isAdmin = currentUser?.role === UserRole.ADMIN;

    const handleSelectTrack = (track: Track) => {
        setSelectedTrack(track);
    }

    return (
        <div className="animate-fade-in space-y-8">
             <div className="flex justify-between items-center">
                <h1 className="text-4xl font-bold text-slate-800 dark:text-white tracking-tight">Campus Radio</h1>
                {isAdmin && 
                    <button 
                        onClick={() => setIsModalOpen(true)} 
                        className="flex items-center gap-2 bg-blue-500 text-white font-semibold px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors shadow"
                    >
                        <UploadIcon />
                        Upload Track
                    </button>
                }
             </div>

            <RadioPlayer track={selectedTrack} />

            <div>
                <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4 tracking-tight">Popular Playlists</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
                    {MOCK_PLAYLISTS.map(playlist => <PlaylistCard key={playlist.id} playlist={playlist} />)}
                </div>
            </div>
            
            <div>
                <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4 tracking-tight">Up Next</h2>
                <div className="space-y-2">
                {MOCK_TRACKS.map(track => (
                    <div key={track.id} onClick={() => handleSelectTrack(track)} className={`flex items-center p-2 rounded-lg cursor-pointer transition-colors ${selectedTrack.id === track.id ? 'bg-blue-100 dark:bg-blue-900/50' : 'hover:bg-slate-200 dark:hover:bg-slate-700'}`}>
                        <img src={track.coverArt} alt={track.title} className="w-12 h-12 rounded-md" />
                        <div className="ml-4">
                            <p className="font-semibold text-slate-800 dark:text-white">{track.title}</p>
                            <p className="text-sm text-slate-500 dark:text-slate-400">{track.artist}</p>
                        </div>
                        <p className="ml-auto text-sm text-slate-500 dark:text-slate-400">{track.duration}</p>
                    </div>
                ))}
                </div>
            </div>

            {isModalOpen && <UploadTrackModal onClose={() => setIsModalOpen(false)} onUpload={() => {
                // Handle upload logic
                setIsModalOpen(false);
            }} />}
        </div>
    );
};
