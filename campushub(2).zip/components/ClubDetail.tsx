import React, { useState } from 'react';
import { Club, ClubEvent, ClubMember, User, UserRole } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { UsersIcon } from './icons/UsersIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { PlusIcon } from './icons/PlusIcon';
import { AddEventModal } from './AddEventModal';
import { AddMemberModal } from './AddMemberModal';

interface ClubDetailProps {
    club: Club;
    onClose: () => void;
    currentUser: User | null;
    onUpdateClub: (club: Club) => void;
}

export const ClubDetail: React.FC<ClubDetailProps> = ({ club, onClose, currentUser, onUpdateClub }) => {
    const [isAddingEvent, setIsAddingEvent] = useState(false);
    const [isAddingMember, setIsAddingMember] = useState(false);

    const isClubAdmin = currentUser?.role === UserRole.CLUB_MEMBER && currentUser?.club === club.name;
    const isSuperAdmin = currentUser?.role === UserRole.ADMIN;

    const handleAddEvent = (event: Omit<ClubEvent, 'id'>) => {
        const newEvent: ClubEvent = { ...event, id: `e${club.events.length + 1}` };
        const updatedClub = { ...club, events: [newEvent, ...club.events] };
        onUpdateClub(updatedClub);
    };
    
    const handleAddMember = (member: ClubMember) => {
        const updatedClub = { ...club, members: [...club.members, member] };
        onUpdateClub(updatedClub);
    };

    return (
        <>
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
                <div className="bg-slate-100 dark:bg-slate-900 rounded-2xl shadow-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto flex flex-col" onClick={e => e.stopPropagation()}>
                    {/* Header with Banner */}
                    <div className="relative flex-shrink-0 h-64">
                        <img src={club.bannerUrl} alt={`${club.name} banner`} className="absolute inset-0 w-full h-full object-cover rounded-t-2xl" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent rounded-t-2xl"></div>
                        <button onClick={onClose} className="absolute top-4 right-4 text-white bg-black/40 p-1.5 rounded-full hover:bg-black/60 transition z-10">
                            <CloseIcon />
                        </button>
                         <div className="absolute bottom-0 left-0 p-8 w-full flex items-end gap-6">
                            <img src={club.logoUrl} alt={`${club.name} logo`} className="w-32 h-32 rounded-full object-contain bg-white p-1.5 border-4 border-white dark:border-slate-800 shadow-lg flex-shrink-0" />
                            <div>
                                <h1 className="text-4xl font-bold tracking-tight text-white drop-shadow-lg">{club.name}</h1>
                                <p className="text-sm font-medium text-slate-300 mt-1">{club.category}</p>
                            </div>
                        </div>
                    </div>
                    
                    {/* Content */}
                    <div className="px-8 py-8 flex-grow bg-white dark:bg-slate-800 rounded-b-2xl">
                        <p className="text-slate-600 dark:text-slate-300 mb-10 max-w-3xl">{club.longDescription}</p>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                            {/* Members Section */}
                            <div>
                                <div className="flex justify-between items-center mb-4">
                                    <h2 className="text-xl font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2">
                                        <UsersIcon /> Members
                                    </h2>
                                    {(isClubAdmin || isSuperAdmin) && (
                                        <button onClick={() => setIsAddingMember(true)} className="text-sm bg-blue-500 text-white font-semibold px-3 py-1 rounded-full flex items-center gap-1 hover:bg-blue-600 transition-colors">
                                            <PlusIcon /> Add
                                        </button>
                                    )}
                                </div>
                                <div className="space-y-3">
                                    {club.members.map(member => (
                                        <div key={member.name} className="flex items-center gap-4 bg-slate-100 dark:bg-slate-700/50 p-3 rounded-xl transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
                                            <img src={member.avatarUrl} alt={member.name} className="w-12 h-12 rounded-full" />
                                            <div>
                                                <p className="font-semibold text-slate-800 dark:text-slate-100">{member.name}</p>
                                                <p className="text-sm text-slate-500 dark:text-slate-400">{member.role}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            {/* Events Section */}
                            <div>
                                 <div className="flex justify-between items-center mb-4">
                                    <h2 className="text-xl font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2">
                                        <CalendarIcon /> Events
                                    </h2>
                                    {(isClubAdmin || isSuperAdmin) && (
                                         <button onClick={() => setIsAddingEvent(true)} className="text-sm bg-blue-500 text-white font-semibold px-3 py-1 rounded-full flex items-center gap-1 hover:bg-blue-600 transition-colors">
                                            <PlusIcon /> Add
                                        </button>
                                    )}
                                </div>
                                 <div className="space-y-3">
                                    {club.events.map(event => (
                                        <div key={event.id} className="bg-slate-100 dark:bg-slate-700/50 p-4 rounded-xl transition-all duration-300 hover:shadow-md hover:scale-[1.02]">
                                            <p className="font-bold text-slate-800 dark:text-slate-100">{event.title}</p>
                                            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium my-1">{event.date}</p>
                                            <p className="text-sm text-slate-600 dark:text-slate-300 mt-2">{event.description}</p>
                                        </div>
                                    ))}
                                    {club.events.length === 0 && <p className="text-sm text-slate-500 dark:text-slate-400 p-4 bg-slate-100 dark:bg-slate-700/50 rounded-xl text-center">No upcoming events.</p>}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {isAddingEvent && <AddEventModal onClose={() => setIsAddingEvent(false)} onAddEvent={handleAddEvent} />}
            {isAddingMember && <AddMemberModal onClose={() => setIsAddingMember(false)} onAddMember={handleAddMember} />}
        </>
    );
};