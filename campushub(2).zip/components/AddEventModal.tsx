import React, { useState } from 'react';
import { ClubEvent } from '../types';
import { CloseIcon } from './icons/CloseIcon';

interface AddEventModalProps {
    onClose: () => void;
    onAddEvent: (event: Omit<ClubEvent, 'id'>) => void;
}

export const AddEventModal: React.FC<AddEventModalProps> = ({ onClose, onAddEvent }) => {
    const [title, setTitle] = useState('');
    const [date, setDate] = useState('');
    const [description, setDescription] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !date || !description) return;
        onAddEvent({ title, date, description });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl max-w-md w-full" onClick={e => e.stopPropagation()}>
                <div className="p-6 relative">
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-4">Add New Event</h2>
                    <button onClick={onClose} className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition"><CloseIcon /></button>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label htmlFor="title" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Event Title</label>
                            <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} required className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="date" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Date</label>
                            <input type="text" id="date" value={date} onChange={e => setDate(e.target.value)} placeholder="e.g., May 25" required className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="description" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Description</label>
                            <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} rows={3} required className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition"></textarea>
                        </div>
                        <button type="submit" className="w-full bg-blue-500 text-white py-2.5 rounded-lg font-semibold hover:bg-blue-600 transition-colors">Add Event</button>
                    </form>
                </div>
            </div>
        </div>
    );
};
