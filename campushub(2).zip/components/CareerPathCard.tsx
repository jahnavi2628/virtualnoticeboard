import React from 'react';
import { CareerPath } from '../types';

interface CareerPathCardProps {
    path: CareerPath;
}

export const CareerPathCard: React.FC<CareerPathCardProps> = ({ path }) => {
    return (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-6 flex flex-col h-full">
            <h3 className="text-xl font-bold text-slate-800 dark:text-white tracking-tight">{path.title}</h3>
            <p className="text-slate-500 dark:text-slate-400 mt-2 flex-grow">{path.description}</p>
            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                <h4 className="font-semibold text-sm text-slate-600 dark:text-slate-300 mb-2">Key Skills:</h4>
                <div className="flex flex-wrap gap-2">
                    {path.skills.map(skill => (
                        <span key={skill} className="text-xs font-medium bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200 px-2.5 py-1 rounded-full">{skill}</span>
                    ))}
                </div>
            </div>
            <button className="mt-6 w-full bg-blue-500 text-white py-2 rounded-lg font-semibold hover:bg-blue-600 transition-colors">
                Explore Path
            </button>
        </div>
    );
};