import React from 'react';
import { User } from '../types';
import { View } from './Sidebar';
import { NoticeIcon } from './icons/NoticeIcon';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { UsersIcon } from './icons/UsersIcon';
import { TrophyIcon } from './icons/TrophyIcon';
import { ChatIcon } from './icons/ChatIcon';
import { ToolsIcon } from './icons/ToolsIcon';

interface DashboardProps {
    currentUser: User | null;
    setActiveView: (view: View) => void;
}

const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: string; onClick: () => void; color: string }> = ({ icon, label, value, onClick, color }) => (
    <div onClick={onClick} className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg cursor-pointer transition-all duration-300 ease-in-out hover:shadow-xl hover:-translate-y-1">
        <div className="flex items-center gap-4">
            <div className={`p-3 rounded-lg ${color}`}>
                {icon}
            </div>
            <div>
                <p className="text-sm text-slate-500 dark:text-slate-400">{label}</p>
                <p className="text-2xl font-bold text-slate-800 dark:text-white">{value}</p>
            </div>
        </div>
    </div>
);

export const Dashboard: React.FC<DashboardProps> = ({ currentUser, setActiveView }) => {
    const firstName = currentUser?.name.split(' ')[0];

    return (
        <div className="animate-fade-in space-y-8">
            <div>
                <h1 className="text-4xl font-bold text-slate-800 dark:text-white tracking-tight">Welcome back, {firstName}!</h1>
                <p className="text-slate-500 dark:text-slate-400 mt-2">Here's a quick overview of what's happening on campus today.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                 <StatCard icon={<NoticeIcon />} label="Recent Notices" value="12" onClick={() => setActiveView('notices')} color="bg-blue-100 dark:bg-blue-900/50 text-blue-500" />
                 <StatCard icon={<BriefcaseIcon />} label="New Job Postings" value="8" onClick={() => setActiveView('placements')} color="bg-green-100 dark:bg-green-900/50 text-green-500" />
                 <StatCard icon={<UsersIcon />} label="Active Clubs" value="15" onClick={() => setActiveView('clubs')} color="bg-yellow-100 dark:bg-yellow-900/50 text-yellow-500" />
                 <StatCard icon={<TrophyIcon />} label="New Achievements" value="5" onClick={() => setActiveView('achievements')} color="bg-red-100 dark:bg-red-900/50 text-red-500" />
            </div>

            {/* Quick Actions Section */}
            <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
                <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4 tracking-tight">Quick Actions</h2>
                <div className="flex flex-wrap gap-4">
                    <button onClick={() => setActiveView('notices')} className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-700 rounded-lg font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600 transition"><NoticeIcon /> View Notices</button>
                    <button onClick={() => setActiveView('chat')} className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-700 rounded-lg font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600 transition"><ChatIcon /> Open Chat</button>
                    <button onClick={() => setActiveView('tools')} className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-700 rounded-lg font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600 transition"><ToolsIcon /> Use Student Tools</button>
                </div>
            </div>
        </div>
    );
};
