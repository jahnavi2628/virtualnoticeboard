import React, { useState } from 'react';
import { MOCK_CLUBS } from '../constants';
import { Club, User } from '../types';
import { ClubCard } from './ClubCard';
import { ClubDetail } from './ClubDetail';

interface ClubsPageProps {
    currentUser: User | null;
}

export const ClubsPage: React.FC<ClubsPageProps> = ({ currentUser }) => {
    const [selectedClub, setSelectedClub] = useState<Club | null>(null);
    const [clubs, setClubs] = useState<Club[]>(MOCK_CLUBS);
    const [activeCategory, setActiveCategory] = useState<'All' | 'Technical' | 'Non-Technical' | 'Cultural'>('All');

    const handleUpdateClub = (updatedClub: Club) => {
        setClubs(prevClubs => prevClubs.map(c => c.id === updatedClub.id ? updatedClub : c));
        setSelectedClub(updatedClub);
    };

    const filteredClubs = clubs.filter(club => 
        activeCategory === 'All' || club.category === activeCategory
    );

    const categories = ['All', 'Technical', 'Non-Technical', 'Cultural'];

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-8 tracking-tight">Student Clubs</h1>
            
            <div className="mb-6 flex flex-wrap gap-2">
                 {categories.map(category => (
                    <button
                        key={category}
                        onClick={() => setActiveCategory(category as any)}
                        className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors ${
                            activeCategory === category
                                ? 'bg-blue-500 text-white shadow-md'
                                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                    >
                        {category}
                    </button>
                ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {filteredClubs.map(club => (
                    <ClubCard key={club.id} club={club} onSelect={setSelectedClub} />
                ))}
            </div>

            {selectedClub && (
                <ClubDetail 
                    club={selectedClub} 
                    onClose={() => setSelectedClub(null)} 
                    currentUser={currentUser}
                    onUpdateClub={handleUpdateClub}
                />
            )}
        </div>
    );
};
