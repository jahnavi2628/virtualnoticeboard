import React from 'react';
import { Sidebar, View } from './Sidebar';
import { Header } from './Header';
import { Dashboard } from './Dashboard';
import { NoticeBoard } from './NoticeBoard';
import { Chat } from './Chat';
import { Tools } from './Tools';
import { AdminPanel } from './AdminPanel';
import { User, Notice } from '../types';
import { Placements } from './Placements';
import { Achievements } from './Achievements';
import { Gallery } from './Gallery';
import { ClubsPage } from './ClubsPage';
import { RadioCell } from './RadioCell';
import { CareerGuidance } from './CareerGuidance';

interface LayoutProps {
    currentUser: User | null;
    setCurrentUser: (user: User | null) => void;
    activeView: View;
    setActiveView: (view: View) => void;
    notices: Notice[];
    onCreateNotice: (newNoticeData: Omit<Notice, 'id' | 'date' | 'isPinned'>) => void;
}

export const Layout: React.FC<LayoutProps> = ({ 
    currentUser, 
    setCurrentUser, 
    activeView, 
    setActiveView,
    notices,
    onCreateNotice
}) => {
    
    const renderView = () => {
        switch(activeView) {
            case 'dashboard': return <Dashboard currentUser={currentUser} setActiveView={setActiveView} />;
            case 'notices': return <NoticeBoard notices={notices} />;
            case 'placements': return <Placements />;
            case 'career': return <CareerGuidance />;
            case 'achievements': return <Achievements />;
            case 'clubs': return <ClubsPage currentUser={currentUser} />;
            case 'gallery': return <Gallery />;
            case 'radio': return <RadioCell currentUser={currentUser} />;
            case 'chat': return <Chat />;
            case 'tools': return <Tools />;
            case 'admin': return <AdminPanel onCreateNotice={onCreateNotice} currentUser={currentUser} />;
            default: return <Dashboard currentUser={currentUser} setActiveView={setActiveView}/>;
        }
    }

    return (
        <div className="flex h-screen bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-200">
            <Sidebar activeView={activeView} setActiveView={setActiveView} currentUser={currentUser} />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header currentUser={currentUser} setCurrentUser={setCurrentUser} />
                <main className="flex-1 overflow-x-hidden overflow-y-auto p-6 lg:p-8">
                    {renderView()}
                </main>
            </div>
        </div>
    );
};