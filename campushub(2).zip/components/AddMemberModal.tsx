import React, { useState } from 'react';
import { ClubMember } from '../types';
import { CloseIcon } from './icons/CloseIcon';

interface AddMemberModalProps {
    onClose: () => void;
    onAddMember: (member: ClubMember) => void;
}

export const AddMemberModal: React.FC<AddMemberModalProps> = ({ onClose, onAddMember }) => {
    const [name, setName] = useState('');
    const [role, setRole] = useState<'President' | 'Member'>('Member');
    const [avatarUrl, setAvatarUrl] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !role) return;
        onAddMember({ name, role, avatarUrl: avatarUrl || `https://i.pravatar.cc/150?u=${name.replace(/\s/g, '')}` });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl max-w-md w-full" onClick={e => e.stopPropagation()}>
                <div className="p-6 relative">
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-4">Add New Member</h2>
                    <button onClick={onClose} className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition"><CloseIcon /></button>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Member Name</label>
                            <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} required className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="role" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Role</label>
                            <select id="role" value={role} onChange={e => setRole(e.target.value as 'President' | 'Member')} className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition">
                                <option>Member</option>
                                <option>President</option>
                            </select>
                        </div>
                         <div>
                            <label htmlFor="avatarUrl" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Avatar URL (Optional)</label>
                            <input type="text" id="avatarUrl" value={avatarUrl} onChange={e => setAvatarUrl(e.target.value)} placeholder="Defaults to a random avatar" className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition" />
                        </div>
                        <button type="submit" className="w-full bg-blue-500 text-white py-2.5 rounded-lg font-semibold hover:bg-blue-600 transition-colors">Add Member</button>
                    </form>
                </div>
            </div>
        </div>
    );
};
