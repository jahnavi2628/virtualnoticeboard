import React, { useState, useMemo, useEffect } from 'react';
import { MOCK_BRANCHES } from '../constants';
import { Branch, Semester } from '../types';

export const GPACalculator: React.FC = () => {
    const [selectedBranch, setSelectedBranch] = useState<Branch>(MOCK_BRANCHES[0]);
    const [selectedSem, setSelectedSem] = useState<Semester>(MOCK_BRANCHES[0].semesters[0]);
    const [grades, setGrades] = useState<Record<string, number>>({});

    useEffect(() => {
        setGrades({});
    }, [selectedSem]);

    const handleBranchChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const branch = MOCK_BRANCHES.find(b => b.name === e.target.value)!;
        setSelectedBranch(branch);
        setSelectedSem(branch.semesters[0]);
    };

    const handleSemChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const sem = selectedBranch.semesters.find(s => s.name === e.target.value)!;
        setSelectedSem(sem);
    };

    const handleGradeChange = (subjectName: string, grade: string) => {
        setGrades(prev => ({ ...prev, [subjectName]: parseInt(grade, 10) || 0 }));
    };

    const gpa = useMemo(() => {
        const totalCredits = selectedSem.subjects.reduce((acc, sub) => acc + sub.credits, 0);
        if (totalCredits === 0) return 0;
        const totalPoints = selectedSem.subjects.reduce((acc, sub) => {
            const gradePoint = grades[sub.name] || 0;
            return acc + (gradePoint * sub.credits);
        }, 0);
        
        const subjectsWithGrades = Object.keys(grades).filter(key => grades[key] > 0).length;
        if (subjectsWithGrades !== selectedSem.subjects.length) return "0.00";

        return (totalPoints / totalCredits).toFixed(2);
    }, [grades, selectedSem]);

    const SelectInput:React.FC<{label:string, value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, children: React.ReactNode}> = ({label, value, onChange, children}) => (
         <div>
            <label className="block text-sm font-medium mb-1 text-slate-600 dark:text-slate-300">{label}</label>
            <select onChange={onChange} value={value} className="w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition">
                {children}
            </select>
        </div>
    );

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            <div className="space-y-4">
                <SelectInput label="Branch" value={selectedBranch.name} onChange={handleBranchChange}>
                     {MOCK_BRANCHES.map(b => <option key={b.name} value={b.name}>{b.name}</option>)}
                </SelectInput>
                <SelectInput label="Semester" value={selectedSem.name} onChange={handleSemChange}>
                    {selectedBranch.semesters.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                </SelectInput>
                
                <div className="pt-4 space-y-3">
                    <h3 className="font-semibold text-slate-700 dark:text-slate-200">Enter Grades</h3>
                    {selectedSem.subjects.map(subject => (
                        <div key={subject.name} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
                            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{subject.name} <span className="text-xs opacity-70">({subject.credits} cr)</span></span>
                            <select onChange={e => handleGradeChange(subject.name, e.target.value)} className="p-1 text-sm bg-white dark:bg-slate-600 rounded-md border border-slate-200 dark:border-slate-500 focus:ring-1 focus:ring-blue-500 focus:outline-none transition">
                                <option value="0">Grade</option>
                                <option value="10">O</option>
                                <option value="9">A+</option>
                                <option value="8">A</option>
                                <option value="7">B+</option>
                                <option value="6">B</option>
                                <option value="5">C</option>
                                <option value="0">F</option>
                            </select>
                        </div>
                    ))}
                </div>
            </div>
            <div className="flex items-center justify-center p-6 bg-slate-100 dark:bg-slate-700/50 rounded-xl h-full">
                <div className="text-center">
                    <p className="text-slate-500 dark:text-slate-400">Your Calculated GPA is</p>
                    <div className="text-7xl font-bold my-2 bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-cyan-400">
                        {gpa}
                    </div>
                </div>
            </div>
        </div>
    );
};