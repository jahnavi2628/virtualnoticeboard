import React from 'react';
import type { QuickLink } from '../types';
import { LinkIcon } from './icons/LinkIcon';

interface QuickLinksProps {
    links: QuickLink[];
}

export const QuickLinks: React.FC<QuickLinksProps> = ({ links }) => {
    return (
        <div className="space-y-3">
            {links.map(link => (
                <a 
                    key={link.name} 
                    href={link.url} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="flex items-center p-4 bg-white dark:bg-slate-800 rounded-xl shadow-md hover:shadow-xl hover:scale-105 transition-all duration-300"
                >
                    <div className="p-2 bg-blue-100 dark:bg-blue-900/50 rounded-lg">
                        <LinkIcon />
                    </div>
                    <span className="ml-4 font-semibold text-slate-700 dark:text-slate-200">{link.name}</span>
                    <span className="ml-auto text-slate-400 dark:text-slate-500">&rarr;</span>
                </a>
            ))}
        </div>
    );
};