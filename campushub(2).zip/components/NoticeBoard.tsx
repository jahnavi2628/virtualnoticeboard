import React, { useState } from 'react';
import { Notice, NoticeCategory } from '../types';
import { NoticeCard } from './NoticeCard';
import { NoticeDetail } from './NoticeDetail';
import { GeneralIcon } from './icons/GeneralIcon';
import { ClubIcon } from './icons/ClubIcon';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { TrophyIcon } from './icons/TrophyIcon';
import { TechIcon } from './icons/TechIcon';
import { NonTechIcon } from './icons/NonTechIcon';
import { CollegeIcon } from './icons/CollegeIcon';
import { NoticeIcon } from './icons/NoticeIcon';

interface NoticeBoardProps {
    notices: Notice[];
}

const categoryIcons: Record<NoticeCategory, React.ReactNode> = {
    [NoticeCategory.GENERAL]: <NoticeIcon />,
    [NoticeCategory.ACADEMICS]: <CollegeIcon />,
    [NoticeCategory.CLUB]: <ClubIcon />,
    [NoticeCategory.PLACEMENTS]: <BriefcaseIcon />,
    [NoticeCategory.SPORTS]: <TrophyIcon />,
    [NoticeCategory.TECH]: <TechIcon />,
    [NoticeCategory.NON_TECH]: <NonTechIcon />,
    [NoticeCategory.COLLEGE]: <CollegeIcon />,
};

export const NoticeBoard: React.FC<NoticeBoardProps> = ({ notices }) => {
    const [selectedNotice, setSelectedNotice] = useState<Notice | null>(null);
    const [activeCategory, setActiveCategory] = useState<NoticeCategory | 'All'>('All');

    const filteredNotices = notices.filter(notice => 
        activeCategory === 'All' || notice.category === activeCategory
    );
    
    const categories: ('All' | NoticeCategory)[] = ['All', ...Object.values(NoticeCategory)];

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-8 tracking-tight">Notice Board</h1>

            <div className="mb-6 flex flex-wrap gap-2">
                {categories.map(category => (
                    <button
                        key={category}
                        onClick={() => setActiveCategory(category)}
                        className={`px-4 py-2 text-sm font-semibold rounded-full flex items-center gap-2 transition-colors ${
                            activeCategory === category
                                ? 'bg-blue-500 text-white shadow-md'
                                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                    >
                         {category !== 'All' && categoryIcons[category]}
                        {category}
                    </button>
                ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredNotices.map(notice => (
                    <NoticeCard key={notice.id} notice={notice} onSelect={setSelectedNotice} />
                ))}
            </div>
            
            {selectedNotice && (
                <NoticeDetail notice={selectedNotice} onClose={() => setSelectedNotice(null)} />
            )}
        </div>
    );
};
