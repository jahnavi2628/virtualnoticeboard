import React, { useState } from 'react';
import { MOCK_CAREER_PATHS, MOCK_CAREER_RESOURCES } from '../constants';
import { CareerPathCard } from './CareerPathCard';
import { CareerResourceCard } from './CareerResourceCard';
import { CareerIcon } from './icons/CareerIcon';

export const CareerGuidance: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'resources' | 'paths'>('resources');

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-8 tracking-tight flex items-center gap-3">
                <CareerIcon /> Career Guidance
            </h1>

            <div className="flex items-center gap-2 mb-6 p-2 bg-slate-200 dark:bg-slate-800 rounded-lg self-start">
                <button
                    onClick={() => setActiveTab('resources')}
                    className={`px-4 py-2 font-semibold text-sm rounded-md transition-colors ${activeTab === 'resources' ? 'bg-blue-500 text-white' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                >
                    Resources
                </button>
                <button
                    onClick={() => setActiveTab('paths')}
                    className={`px-4 py-2 font-semibold text-sm rounded-md transition-colors ${activeTab === 'paths' ? 'bg-blue-500 text-white' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                >
                    Career Paths
                </button>
            </div>
            
            {activeTab === 'resources' ? (
                 <div>
                    <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4 tracking-tight">Helpful Resources</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {MOCK_CAREER_RESOURCES.map(resource => (
                            <CareerResourceCard key={resource.id} resource={resource} />
                        ))}
                    </div>
                </div>
            ) : (
                <div>
                    <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4 tracking-tight">Explore Career Paths</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {MOCK_CAREER_PATHS.map(path => (
                            <CareerPathCard key={path.id} path={path} />
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};
