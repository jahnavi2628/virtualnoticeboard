
import React from 'react';
import { Job } from '../types';

interface JobCardProps {
    job: Job;
}

export const JobCard: React.FC<JobCardProps> = ({ job }) => {
    return (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg flex flex-col p-6 transition-all duration-300 ease-in-out hover:shadow-2xl hover:-translate-y-1">
            <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                    <img src={job.logoUrl} alt={`${job.company} logo`} className="w-12 h-12 rounded-lg object-contain bg-white p-1" />
                    <div>
                        <h3 className="text-lg font-bold text-slate-800 dark:text-white tracking-tight">{job.title}</h3>
                        <p className="text-sm font-medium text-slate-600 dark:text-slate-300">{job.company}</p>
                    </div>
                </div>
                <span className={`text-xs font-semibold px-2 py-1 rounded-full ${job.type === 'Full-time' ? 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300' : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/50 dark:text-yellow-300'}`}>
                    {job.type}
                </span>
            </div>
            
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-2">{job.location}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-semibold">{job.salary}</p>

            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
                 <p className="text-sm text-slate-600 dark:text-slate-300">{job.description.substring(0, 100)}...</p>
            </div>
            
            <button className="mt-4 w-full bg-blue-500 text-white py-2 rounded-lg font-semibold hover:bg-blue-600 transition-colors">
                Apply Now
            </button>
        </div>
    );
};
