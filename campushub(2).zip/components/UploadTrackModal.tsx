
import React, { useState } from 'react';
import { CloseIcon } from './icons/CloseIcon';
import { UploadIcon } from './icons/UploadIcon';

interface UploadTrackModalProps {
    onClose: () => void;
    onUpload: (trackData: any) => void;
}

export const UploadTrackModal: React.FC<UploadTrackModalProps> = ({ onClose, onUpload }) => {
    const [title, setTitle] = useState('');
    const [artist, setArtist] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onUpload({ title, artist });
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl max-w-md w-full" onClick={e => e.stopPropagation()}>
                <div className="p-6 relative">
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white mb-4">Upload New Track</h2>
                    <button onClick={onClose} className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition"><CloseIcon /></button>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div className="mt-2 flex justify-center rounded-lg border border-dashed border-slate-900/25 dark:border-slate-100/25 px-6 py-10">
                            <div className="text-center">
                                <UploadIcon />
                                <div className="mt-4 flex text-sm leading-6 text-slate-600 dark:text-slate-400">
                                    <label htmlFor="file-upload" className="relative cursor-pointer rounded-md bg-white dark:bg-slate-800 font-semibold text-blue-600 dark:text-blue-400 focus-within:outline-none focus-within:ring-2 focus-within:ring-blue-600 focus-within:ring-offset-2 hover:text-blue-500">
                                        <span>Upload a file</span>
                                        <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                                    </label>
                                    <p className="pl-1">or drag and drop</p>
                                </div>
                                <p className="text-xs leading-5 text-slate-600 dark:text-slate-400">MP3, WAV up to 10MB</p>
                            </div>
                        </div>
                        <div>
                            <label htmlFor="title" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Track Title</label>
                            <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} required className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition" />
                        </div>
                        <div>
                            <label htmlFor="artist" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Artist</label>
                             <input type="text" id="artist" value={artist} onChange={e => setArtist(e.target.value)} required className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition" />
                        </div>
                        <button type="submit" className="w-full bg-blue-500 text-white py-2.5 rounded-lg font-semibold hover:bg-blue-600 transition-colors">Upload Track</button>
                    </form>
                </div>
            </div>
        </div>
    );
};
