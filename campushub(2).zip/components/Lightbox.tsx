import React from 'react';
import { GalleryImage } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { DownloadIcon } from './icons/DownloadIcon';

interface LightboxProps {
    image: GalleryImage;
    onClose: () => void;
}

export const Lightbox: React.FC<LightboxProps> = ({ image, onClose }) => {
    return (
        <div
            className="fixed inset-0 bg-black/80 z-50 flex flex-col items-center justify-center p-4 animate-fade-in"
            onClick={onClose}
        >
            <div
                className="relative"
                onClick={(e) => e.stopPropagation()}
            >
                <img
                    src={image.src}
                    alt={image.alt}
                    className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl"
                />
                <div className="absolute top-3 right-3 flex items-center gap-2">
                     <a
                        href={image.src}
                        download={`CampusHub-Image-${image.id}.jpg`}
                        className="flex items-center justify-center text-white bg-black/50 rounded-full w-10 h-10 hover:bg-black/80 transition-colors"
                        title="Download image"
                    >
                        <DownloadIcon />
                    </a>
                    <button
                        onClick={onClose}
                        className="flex items-center justify-center text-white bg-black/50 rounded-full w-10 h-10 hover:bg-black/80 transition-colors"
                        title="Close"
                    >
                        <CloseIcon />
                    </button>
                </div>
            </div>
            <p className="text-center text-white mt-3 text-sm font-medium">{image.alt}</p>
        </div>
    );
};
