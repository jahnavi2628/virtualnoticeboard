
import React, { useState, useEffect } from 'react';
import { Notice, NoticeCategory, User, UserRole } from '../types';

interface AdminPanelProps {
    onCreateNotice: (newNoticeData: Omit<Notice, 'id' | 'date' | 'isPinned'>) => void;
    currentUser: User | null;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onCreateNotice, currentUser }) => {
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [category, setCategory] = useState<NoticeCategory>(NoticeCategory.GENERAL);
    const [author, setAuthor] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    
    const isClubMember = currentUser?.role === UserRole.CLUB_MEMBER;

    useEffect(() => {
        if (isClubMember) {
            setCategory(NoticeCategory.CLUB);
            setAuthor(currentUser.club || '');
        } else {
            setCategory(NoticeCategory.GENERAL);
            setAuthor('');
        }
    }, [currentUser, isClubMember]);


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !content || !author) {
            alert("Please fill all required fields");
            return;
        }
        onCreateNotice({ title, content, category, author, imageUrl });
        setTitle('');
        setContent('');
        setImageUrl('');

        if (!isClubMember) {
            setCategory(NoticeCategory.GENERAL);
            setAuthor('');
        }

        alert("Notice created successfully!");
    };

    const InputField: React.FC<{label: string, id: string, value: string, onChange: (val: string) => void, type?: string, required?: boolean, disabled?: boolean}> = ({label, id, value, onChange, type="text", required=true, disabled=false}) => (
        <div>
            <label htmlFor={id} className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">{label}</label>
            <input type={type} id={id} value={value} onChange={e => onChange(e.target.value)} required={required} disabled={disabled} className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition disabled:opacity-50 disabled:cursor-not-allowed" />
        </div>
    );

    if (!currentUser || currentUser.role === UserRole.STUDENT) {
        return (
             <div className="text-center p-8 bg-white dark:bg-slate-800 rounded-xl shadow-lg">
                <h2 className="text-2xl font-bold text-red-500">Access Denied</h2>
                <p className="text-slate-600 dark:text-slate-300 mt-2">You do not have permission to view this page.</p>
            </div>
        )
    }

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-8 tracking-tight">
                {isClubMember ? `Create Event for ${currentUser.club}` : 'Create a New Notice'}
            </h1>
            <div className="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-lg max-w-2xl mx-auto">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <InputField label="Title" id="title" value={title} onChange={setTitle} />
                    <div>
                        <label htmlFor="content" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Content</label>
                        <textarea id="content" value={content} onChange={e => setContent(e.target.value)} rows={5} required className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition"></textarea>
                    </div>
                    <div>
                        <label htmlFor="category" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Category</label>
                        <select id="category" value={category} onChange={e => setCategory(e.target.value as NoticeCategory)} disabled={isClubMember} className="mt-1 block w-full p-2.5 bg-slate-100 dark:bg-slate-700 rounded-lg border border-slate-200 dark:border-slate-600 focus:ring-2 focus:ring-blue-500 focus:outline-none transition disabled:opacity-50 disabled:cursor-not-allowed">
                            {/* FIX: Add explicit type annotation to resolve TS error with Object.values on enums */}
                            {Object.values(NoticeCategory).map((cat: NoticeCategory) => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                    </div>
                    <InputField label="Author / Club Name" id="author" value={author} onChange={setAuthor} disabled={isClubMember} />
                    <InputField label="Image URL (Optional)" id="imageUrl" value={imageUrl} onChange={setImageUrl} required={false} />
                    
                    <button type="submit" className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-blue-500 to-cyan-400 text-white py-3 px-4 rounded-lg font-semibold hover:opacity-90 transition-opacity shadow-lg">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>
                        Publish Notice
                    </button>
                </form>
            </div>
        </div>
    );
};
