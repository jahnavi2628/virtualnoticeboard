import React from 'react';
import { MOCK_ACHIEVEMENTS } from '../constants';
import { TrophyIcon } from './icons/TrophyIcon';

export const Achievements: React.FC = () => {
    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-8 tracking-tight flex items-center gap-3">
                <TrophyIcon /> Student Achievements
            </h1>
            <div className="space-y-6">
                {MOCK_ACHIEVEMENTS.map(achievement => (
                    <div key={achievement.id} className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-6 flex items-center gap-6 transition-all hover:shadow-xl hover:scale-[1.02]">
                        <img src={achievement.avatarUrl} alt={achievement.studentName} className="w-16 h-16 rounded-full flex-shrink-0 object-cover" />
                        <div className="flex-1">
                            <p className="text-lg font-semibold text-slate-800 dark:text-white">{achievement.achievement}</p>
                            <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                                <span className="font-medium">{achievement.studentName}</span> at <span className="font-medium text-blue-500">{achievement.competition}</span>
                            </p>
                        </div>
                        <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">{achievement.date}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};
