
import React from 'react';
import { Notice } from '../types';
import { PinIcon } from './icons/PinIcon';

interface NoticeCardProps {
    notice: Notice;
    onSelect: (notice: Notice) => void;
}

const getCategoryStyles = (category: string) => {
    switch(category) {
        case 'Academics': return 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300';
        case 'Club Activities': return 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300';
        case 'Placements': return 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300';
        case 'Sports': return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/50 dark:text-yellow-300';
        default: return 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300';
    }
}

export const NoticeCard: React.FC<NoticeCardProps> = ({ notice, onSelect }) => {
    return (
        <div onClick={() => onSelect(notice)} className="bg-white dark:bg-slate-800 rounded-xl shadow-lg flex flex-col cursor-pointer transition-all duration-300 ease-in-out hover:shadow-2xl hover:-translate-y-1">
            {notice.imageUrl && <img src={notice.imageUrl} alt={notice.title} className="rounded-t-xl h-40 w-full object-cover" />}
            <div className="p-5 flex flex-col flex-1">
                <div className="flex justify-between items-start mb-2">
                    <span className={`text-xs px-2 py-1 rounded-full font-semibold ${getCategoryStyles(notice.category)}`}>{notice.category}</span>
                    {notice.isPinned && <span className="text-slate-400 dark:text-slate-500"><PinIcon /></span>}
                </div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white tracking-tight flex-1">{notice.title}</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">{notice.content.substring(0, 100)}...</p>
                <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400">
                    <span>{notice.author} &bull; {notice.date}</span>
                </div>
            </div>
        </div>
    );
};
