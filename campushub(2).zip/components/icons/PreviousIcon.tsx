
import React from 'react';

export const PreviousIcon: React.FC = () => (
    <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path d="M6 6h2v12H6zm3.5 6l8.5 6V6z" />
    </svg>
);
