
import React from 'react';

export const TrophyIcon: React.FC = () => (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6 6 2.69 6 6-2.69 6-6 6zm-1-5H9v2h2v-2zm2 0h-2v2h2v-2zm2 0h-2v2h2v-2z" />
        <path d="M12 6c-1.07 0-2.09.27-3 .75V4h6v2.75c-.91-.48-1.93-.75-3-.75zm0 10c-1.07 0-2.09-.27-3-.75v2h6v-2c-.91.48-1.93-.75-3-.75z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.5 12a3.5 3.5 0 11-7 0 3.5 3.5 0 017 0z" />
    </svg>
);
