import React from 'react';
import { CareerResource } from '../types';

interface CareerResourceCardProps {
    resource: CareerResource;
}

export const CareerResourceCard: React.FC<CareerResourceCardProps> = ({ resource }) => {
    const getTypeStyles = (type: string) => {
        switch(type) {
            case 'Article': return 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300';
            case 'Video': return 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300';
            case 'Webinar': return 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-300';
            default: return 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300';
        }
    };

    return (
        <a href={resource.url} target="_blank" rel="noopener noreferrer" className="group bg-white dark:bg-slate-800 rounded-xl shadow-lg flex flex-col cursor-pointer transition-all duration-300 ease-in-out hover:shadow-2xl hover:-translate-y-1">
            <img src={resource.thumbnailUrl} alt={resource.title} className="rounded-t-xl h-40 w-full object-cover" />
            <div className="p-5 flex flex-col flex-1">
                <span className={`text-xs px-2 py-1 rounded-full font-semibold self-start ${getTypeStyles(resource.type)}`}>{resource.type}</span>
                <h3 className="text-md font-bold text-slate-800 dark:text-white tracking-tight mt-2 flex-1 group-hover:text-blue-500 transition-colors">{resource.title}</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">{resource.summary}</p>
                <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700 text-xs text-slate-500 dark:text-slate-400">
                    <span>By {resource.author}</span>
                </div>
            </div>
        </a>
    );
};