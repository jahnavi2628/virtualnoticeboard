import React, { useState, useRef, useEffect } from 'react';
import { Track } from '../types';
import { PlayIcon } from './icons/PlayIcon';
import { PauseIcon } from './icons/PauseIcon';
import { NextIcon } from './icons/NextIcon';
import { PreviousIcon } from './icons/PreviousIcon';
import { VolumeIcon } from './icons/VolumeIcon';

interface RadioPlayerProps {
    track: Track;
}

export const RadioPlayer: React.FC<RadioPlayerProps> = ({ track }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);
    const [volume, setVolume] = useState(0.75);
    const audioRef = useRef<HTMLAudioElement>(null);

    const togglePlayPause = () => {
        setIsPlaying(!isPlaying);
    };

    useEffect(() => {
        // Mock audio play progress for UI demonstration
        // FIX: Use ReturnType<typeof setInterval> for browser compatibility instead of NodeJS.Timeout
        let interval: ReturnType<typeof setInterval>;
        if (isPlaying) {
             interval = setInterval(() => {
                setProgress(p => (p >= 100 ? 0 : p + 1));
            }, 500);
        }
        return () => clearInterval(interval);
    }, [isPlaying, track]);
    
    useEffect(() => {
        setProgress(0);
        setIsPlaying(false);
    }, [track]);

    return (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-lg p-6 flex flex-col md:flex-row items-center gap-6">
            <img src={track.coverArt} alt={track.title} className="w-40 h-40 md:w-48 md:h-48 rounded-lg shadow-md flex-shrink-0 object-cover" />
            <div className="flex-1 w-full">
                <h2 className="text-2xl font-bold text-slate-800 dark:text-white">{track.title}</h2>
                <p className="text-slate-500 dark:text-slate-400">{track.artist}</p>
                <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 mt-4">
                    <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${progress}%` }}></div>
                </div>
                <div className="flex justify-between text-xs text-slate-500 dark:text-slate-400 mt-1">
                    <span>0:00</span>
                    <span>{track.duration}</span>
                </div>
                <div className="flex items-center justify-center gap-6 mt-4">
                    <button className="text-slate-600 dark:text-slate-300 hover:text-blue-500 transition-colors"><PreviousIcon /></button>
                    <button onClick={togglePlayPause} className="w-16 h-16 flex items-center justify-center bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600 transition">
                        {isPlaying ? <PauseIcon /> : <PlayIcon />}
                    </button>
                    <button className="text-slate-600 dark:text-slate-300 hover:text-blue-500 transition-colors"><NextIcon /></button>
                </div>
            </div>
             <div className="flex items-center gap-2 w-full md:w-auto mt-4 md:mt-0">
                <VolumeIcon />
                <input type="range" min="0" max="1" step="0.01" value={volume} onChange={(e) => setVolume(parseFloat(e.target.value))} className="w-full md:w-24 h-1 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500" />
            </div>
        </div>
    );
};