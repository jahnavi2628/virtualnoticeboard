import React, { useState } from 'react';
import { MOCK_JOBS } from '../constants';
import { JobCard } from './JobCard';
import { BriefcaseIcon } from './icons/BriefcaseIcon';

export const Placements: React.FC = () => {
    const [filter, setFilter] = useState<'All' | 'Full-time' | 'Internship'>('All');
    
    const filteredJobs = MOCK_JOBS.filter(job => 
        filter === 'All' || job.type === filter
    );

    return (
        <div className="animate-fade-in">
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-4xl font-bold text-slate-800 dark:text-white tracking-tight flex items-center gap-3">
                    <BriefcaseIcon /> Placements & Internships
                </h1>
            </div>


            <div className="mb-6 flex flex-wrap gap-2">
                {(['All', 'Full-time', 'Internship'] as const).map(type => (
                    <button
                        key={type}
                        onClick={() => setFilter(type)}
                        className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors ${
                            filter === type
                                ? 'bg-blue-500 text-white shadow-md'
                                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                        }`}
                    >
                        {type}
                    </button>
                ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
                {filteredJobs.map(job => (
                    <JobCard key={job.id} job={job} />
                ))}
            </div>
        </div>
    );
};
