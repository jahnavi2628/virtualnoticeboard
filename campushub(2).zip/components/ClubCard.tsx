
import React from 'react';
import { Club } from '../types';

interface ClubCardProps {
    club: Club;
    onSelect: (club: Club) => void;
}

export const ClubCard: React.FC<ClubCardProps> = ({ club, onSelect }) => {
    return (
        <div onClick={() => onSelect(club)} className="bg-white dark:bg-slate-800 rounded-xl shadow-lg flex flex-col cursor-pointer transition-all duration-300 ease-in-out hover:shadow-2xl hover:-translate-y-1">
            <img src={club.bannerUrl} alt={club.name} className="rounded-t-xl h-32 w-full object-cover" />
            <div className="p-5 flex flex-col flex-1 items-center text-center -mt-12">
                <img src={club.logoUrl} alt={`${club.name} logo`} className="w-20 h-20 rounded-full object-contain bg-white p-1 border-4 border-white dark:border-slate-800 shadow-lg" />
                <h3 className="text-lg font-bold text-slate-800 dark:text-white tracking-tight mt-2">{club.name}</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{club.description}</p>
            </div>
        </div>
    );
};
