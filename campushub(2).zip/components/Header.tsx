import React, { useState } from 'react';
import { SearchIcon } from './icons/SearchIcon';
import { BellIcon } from './icons/BellIcon';
import { User, UserRole } from '../types';
import { MOCK_USERS } from '../constants';

interface HeaderProps {
    currentUser: User | null;
    setCurrentUser: (user: User | null) => void;
}


export const Header: React.FC<HeaderProps> = ({ currentUser, setCurrentUser }) => {
    const [dropdownOpen, setDropdownOpen] = useState(false);

    const handleUserSelect = (userId: string) => {
        const user = MOCK_USERS.find(u => u.id === userId);
        setCurrentUser(user || null);
        setDropdownOpen(false);
    }
    
    const getRoleStyles = (role: UserRole) => {
        switch (role) {
            case UserRole.ADMIN: return 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300';
            case UserRole.CLUB_MEMBER: return 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300';
            default: return 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300';
        }
    }

    return (
        <header className="flex justify-between items-center px-6 py-4 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700">
            <div className="flex items-center">
                <div className="relative text-slate-600 dark:text-slate-400">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                        <SearchIcon />
                    </span>
                    <input type="search" name="search" className="py-2.5 pl-10 pr-4 text-sm bg-slate-100 dark:bg-slate-700 rounded-full focus:outline-none focus:bg-white dark:focus:bg-slate-600 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 transition-all duration-300 w-64" placeholder="Search anything..." />
                </div>
            </div>
            <div className="flex items-center gap-4">
                <button className="p-2 rounded-full text-slate-500 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-blue-500 dark:hover:text-blue-400 transition-colors">
                    <BellIcon />
                </button>
                <div className="relative">
                    <button onClick={() => setDropdownOpen(!dropdownOpen)} className="flex items-center gap-3 cursor-pointer">
                        {currentUser ? (
                             <>
                                <img className="h-10 w-10 rounded-full object-cover border-2 border-transparent hover:border-blue-500 transition" src={currentUser.avatarUrl} alt="User avatar" />
                                <div>
                                     <p className="font-semibold text-sm text-slate-700 dark:text-slate-200 text-left">{currentUser.name}</p>
                                     <p className={`text-xs px-1.5 py-0.5 rounded-full font-medium inline-block ${getRoleStyles(currentUser.role)}`}>{currentUser.role}</p>
                                </div>
                             </>
                        ) : (
                            <p>Guest</p>
                        )}
                    </button>
                     {dropdownOpen && (
                        <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-700 rounded-lg shadow-xl z-10 animate-fade-in-down">
                            <div className="p-2 text-sm text-slate-500 dark:text-slate-400">Switch User</div>
                            {MOCK_USERS.map(user => (
                                <a 
                                    key={user.id} 
                                    href="#" 
                                    onClick={(e) => { e.preventDefault(); handleUserSelect(user.id); }}
                                    className="flex items-center gap-3 px-4 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600"
                                >
                                     <img src={user.avatarUrl} className="w-8 h-8 rounded-full" />
                                     <div>
                                         <p className="font-medium">{user.name}</p>
                                         <p className={`text-xs ${getRoleStyles(user.role)} px-1 rounded-full inline-block`}>{user.role}</p>
                                     </div>
                                </a>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
};
