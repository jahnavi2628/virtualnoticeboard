
import React from 'react';
import { Playlist } from '../types';
import { PlayIcon } from './icons/PlayIcon';

interface PlaylistCardProps {
    playlist: Playlist;
}

export const PlaylistCard: React.FC<PlaylistCardProps> = ({ playlist }) => {
    return (
        <div className="group cursor-pointer">
            <div className="relative">
                <img src={playlist.coverArt} alt={playlist.name} className="w-full aspect-square object-cover rounded-lg shadow-md transition-transform duration-300 group-hover:scale-105" />
                <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white">
                        <PlayIcon />
                    </div>
                </div>
            </div>
            <h3 className="font-semibold text-slate-800 dark:text-white mt-2 truncate">{playlist.name}</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">{playlist.trackCount} tracks</p>
        </div>
    );
};
