
import React from 'react';

export const ClubEvents: React.FC = () => {
    return (
        <div>
            <h1 className="text-2xl font-bold">Club Events</h1>
            <p>This is where club events will be displayed.</p>
        </div>
    );
};
