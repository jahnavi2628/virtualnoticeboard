import React from 'react';
import { HomeIcon } from './icons/HomeIcon';
import { NoticeIcon } from './icons/NoticeIcon';
import { RadioIcon } from './icons/RadioIcon';
import { ChatIcon } from './icons/ChatIcon';
import { ToolsIcon } from './icons/ToolsIcon';
import { AdminIcon } from './icons/AdminIcon';
import { User, UserRole } from '../types';
import { TrophyIcon } from './icons/TrophyIcon';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { CameraIcon } from './icons/CameraIcon';
import { UsersIcon } from './icons/UsersIcon';
import { LogoIcon } from './icons/LogoIcon';
import { CareerIcon } from './icons/CareerIcon';

export type View = 'dashboard' | 'notices' | 'radio' | 'chat' | 'tools' | 'admin' | 'achievements' | 'placements' | 'gallery' | 'clubs' | 'career';

interface SidebarProps {
    activeView: View;
    setActiveView: (view: View) => void;
    currentUser: User | null;
}

const NavItem: React.FC<{
    icon: React.ReactNode;
    label: string;
    isActive: boolean;
    onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
            isActive
                ? 'bg-blue-500 text-white shadow'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
        }`}
    >
        {icon}
        <span>{label}</span>
    </button>
);

export const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, currentUser }) => {
    const isAdmin = currentUser?.role === UserRole.ADMIN || currentUser?.role === UserRole.CLUB_MEMBER;

    const navItems = [
        { id: 'dashboard', label: 'Dashboard', icon: <HomeIcon />, access: true },
        { id: 'notices', label: 'Notice Board', icon: <NoticeIcon />, access: true },
        { id: 'placements', label: 'Placements', icon: <BriefcaseIcon />, access: true },
        { id: 'career', label: 'Career Guidance', icon: <CareerIcon />, access: true },
        { id: 'achievements', label: 'Achievements', icon: <TrophyIcon />, access: true },
        { id: 'clubs', label: 'Clubs', icon: <UsersIcon />, access: true },
        { id: 'gallery', label: 'Gallery', icon: <CameraIcon />, access: true },
        { id: 'radio', label: 'Campus Radio', icon: <RadioIcon />, access: true },
        { id: 'chat', label: 'Chat', icon: <ChatIcon />, access: true },
        { id: 'tools', label: 'Student Tools', icon: <ToolsIcon />, access: true },
        { id: 'admin', label: 'Admin Panel', icon: <AdminIcon />, access: isAdmin },
    ];


    return (
        <aside className="w-64 bg-white dark:bg-slate-800 p-4 flex flex-col border-r border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-2 px-2 mb-8">
                <LogoIcon />
                <h1 className="text-xl font-bold text-slate-800 dark:text-white">CampusHub</h1>
            </div>
            <nav className="flex flex-col gap-2">
                {navItems.filter(item => item.access).map(item => (
                    <NavItem 
                        key={item.id}
                        icon={item.icon}
                        label={item.label}
                        isActive={activeView === item.id}
                        onClick={() => setActiveView(item.id as View)}
                    />
                ))}
            </nav>
        </aside>
    );
};