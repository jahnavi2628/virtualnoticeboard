
import React, { useState } from 'react';
import { MOCK_GALLERY_IMAGES } from '../constants';
import { GalleryImage } from '../types';
import { Lightbox } from './Lightbox';
import { CameraIcon } from './icons/CameraIcon';

export const Gallery: React.FC = () => {
    const [selectedImage, setSelectedImage] = useState<GalleryImage | null>(null);

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-8 tracking-tight flex items-center gap-3">
                <CameraIcon /> Campus Gallery
            </h1>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {MOCK_GALLERY_IMAGES.map((image) => (
                    <div
                        key={image.id}
                        className="group cursor-pointer"
                        onClick={() => setSelectedImage(image)}
                    >
                        <img
                            src={image.src}
                            alt={image.alt}
                            className="w-full h-48 object-cover rounded-lg shadow-md transition-transform duration-300 group-hover:scale-105"
                        />
                    </div>
                ))}
            </div>
            {selectedImage && <Lightbox image={selectedImage} onClose={() => setSelectedImage(null)} />}
        </div>
    );
};
