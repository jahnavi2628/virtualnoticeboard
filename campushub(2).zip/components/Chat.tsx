
import React, { useState } from 'react';
import { MOCK_MESSAGES } from '../constants';
import { ChatChannel } from '../types';
import { ChatIcon } from './icons/ChatIcon';

export const Chat: React.FC = () => {
    const [activeChannel, setActiveChannel] = useState<ChatChannel>(ChatChannel.GENERAL);
    const messages = MOCK_MESSAGES.filter(m => m.channel === activeChannel);

    return (
        <div className="flex h-[calc(100vh-12rem)]">
            <div className="w-1/4 bg-white dark:bg-slate-800 rounded-l-xl shadow-lg border-r border-slate-200 dark:border-slate-700 flex flex-col p-4">
                <h2 className="text-xl font-bold mb-4 text-slate-800 dark:text-white">Channels</h2>
                <div className="flex flex-col gap-2">
                    {/* FIX: Add explicit type annotation to resolve TS error with Object.values on enums */}
                    {Object.values(ChatChannel).map((channel: ChatChannel) => (
                        <button key={channel} onClick={() => setActiveChannel(channel)} className={`px-4 py-2 rounded-lg text-left font-semibold text-sm capitalize transition-colors ${activeChannel === channel ? 'bg-blue-500 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'}`}># {channel}</button>
                    ))}
                </div>
            </div>

            <div className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-800/50 rounded-r-xl shadow-lg">
                <div className="p-4 border-b border-slate-200 dark:border-slate-700">
                    <h1 className="text-xl font-bold text-slate-800 dark:text-white capitalize"># {activeChannel}</h1>
                    <p className="text-sm text-slate-500 dark:text-slate-400">A place for all things {activeChannel}.</p>
                </div>
                <div className="flex-1 p-6 overflow-y-auto space-y-6">
                    {messages.map((msg, index) => (
                        <div key={msg.id} className={`flex items-start gap-3 ${index % 2 === 0 ? '' : 'justify-end'}`}>
                             {index % 2 === 0 && <img src={msg.avatarUrl} alt={msg.sender} className="w-10 h-10 rounded-full" />}
                            <div className={`p-3 rounded-xl max-w-lg ${index % 2 === 0 ? 'bg-white dark:bg-slate-700' : 'bg-blue-500 text-white'}`}>
                                <div className="flex items-baseline gap-2">
                                    <p className={`font-bold text-sm ${index % 2 !== 0 && 'text-white'}`}>{msg.sender}</p>
                                    <p className={`text-xs ${index % 2 === 0 ? 'text-slate-400' : 'text-blue-200'}`}>{msg.timestamp}</p>
                                </div>
                                <p className="mt-1">{msg.message}</p>
                            </div>
                            {index % 2 !== 0 && <img src={msg.avatarUrl} alt={msg.sender} className="w-10 h-10 rounded-full" />}
                        </div>
                    ))}
                </div>
                <div className="p-4 border-t border-slate-200 dark:border-slate-700">
                     <div className="relative">
                        <input type="text" placeholder={`Message #${activeChannel}`} className="w-full p-3 pl-4 pr-12 bg-white dark:bg-slate-700 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white transition" />
                        <button className="absolute inset-y-0 right-0 flex items-center justify-center w-12 text-blue-500 hover:text-blue-600">
                            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path d="M3.105 3.105a1 1 0 011.414 0L18 16.586V3a1 1 0 112 0v14a1 1 0 01-1 1H3a1 1 0 110-2h13.586L3.105 4.52a1 1 0 010-1.414z" /></svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
