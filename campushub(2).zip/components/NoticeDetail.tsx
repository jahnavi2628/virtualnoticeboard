
import React from 'react';
import { Notice } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { UsersIcon } from './icons/UsersIcon';
import { PlusCircleIcon } from './icons/PlusCircleIcon';

interface NoticeDetailProps {
    notice: Notice;
    onClose: () => void;
}

export const NoticeDetail: React.FC<NoticeDetailProps> = ({ notice, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                {notice.imageUrl && <img src={notice.imageUrl} alt={notice.title} className="rounded-t-xl h-64 w-full object-cover" />}
                <div className="p-8 relative">
                    <button onClick={onClose} className="absolute top-4 right-4 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition">
                        <CloseIcon />
                    </button>
                    <h1 className="text-3xl font-bold text-slate-800 dark:text-white mb-2 tracking-tight">{notice.title}</h1>
                    <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">{notice.author} &bull; {notice.date}</p>
                    <div className="prose dark:prose-invert max-w-none text-slate-600 dark:text-slate-300">
                        <p>{notice.content}</p>
                    </div>

                    {notice.organizers && notice.organizers.length > 0 && (
                        <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">
                            <h2 className="text-xl font-bold text-slate-700 dark:text-slate-200 mb-4 flex items-center gap-2">
                                <UsersIcon /> Event Organizers
                            </h2>
                            <div className="flex flex-wrap gap-4">
                                {notice.organizers.map(organizer => (
                                    <div key={organizer.name} className="flex items-center gap-3 bg-slate-100 dark:bg-slate-700/50 p-2 rounded-lg">
                                        <img src={organizer.avatarUrl} alt={organizer.name} className="w-10 h-10 rounded-full" />
                                        <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{organizer.name}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    
                    {notice.recruitment && (
                         <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">
                            <h2 className="text-xl font-bold text-slate-700 dark:text-slate-200 mb-2 flex items-center gap-2">
                                <PlusCircleIcon /> {notice.recruitment.title}
                            </h2>
                            <p className="text-slate-600 dark:text-slate-300 mb-4">{notice.recruitment.description}</p>
                            <div className="flex flex-wrap gap-2 mb-4">
                                {notice.recruitment.roles.map(role => (
                                    <span key={role} className="text-xs font-medium bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300 px-2.5 py-1 rounded-full">{role}</span>
                                ))}
                            </div>
                            <button className="w-full sm:w-auto bg-blue-500 text-white py-2.5 px-6 rounded-lg font-semibold hover:bg-blue-600 transition-colors shadow-md">
                                Express Interest
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};