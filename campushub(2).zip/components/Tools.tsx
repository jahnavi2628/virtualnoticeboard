import React, { useState } from 'react';
import { GPACalculator } from './GPACalculator';
import { QuickLinks } from './QuickLinks';
import { MOCK_QUICK_LINKS } from '../constants';
import { CalculatorIcon } from './icons/CalculatorIcon';
import { LinkIcon } from './icons/LinkIcon';

type ToolTab = 'gpa' | 'links';

const TabButton: React.FC<{
    icon: React.ReactNode;
    label: string;
    isActive: boolean;
    onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`flex items-center gap-2 px-4 py-2 font-semibold text-sm rounded-md transition-colors ${isActive ? 'bg-blue-500 text-white' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'}`}
    >
        {icon} {label}
    </button>
);


export const Tools: React.FC = () => {
    const [activeTab, setActiveTab] = useState<ToolTab>('gpa');

    return (
        <div className="animate-fade-in">
            <h1 className="text-4xl font-bold text-slate-800 dark:text-white mb-8 tracking-tight">Student Tools</h1>
            
            <div className="flex items-center gap-2 mb-6 p-2 bg-slate-200 dark:bg-slate-800 rounded-lg self-start">
                <TabButton icon={<CalculatorIcon/>} label="GPA Calculator" isActive={activeTab === 'gpa'} onClick={() => setActiveTab('gpa')} />
                <TabButton icon={<LinkIcon />} label="Quick Links" isActive={activeTab === 'links'} onClick={() => setActiveTab('links')} />
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
                {activeTab === 'gpa' ? (
                     <>
                        <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4 tracking-tight">GPA Calculator</h2>
                        <GPACalculator />
                    </>
                ) : (
                    <>
                        <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-4 tracking-tight">Quick Links</h2>
                        <QuickLinks links={MOCK_QUICK_LINKS} />
                    </>
                )}
            </div>
        </div>
    );
};