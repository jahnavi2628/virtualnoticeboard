
export enum UserRole {
    ADMIN = 'Admin',
    CLUB_MEMBER = 'Club Member',
    STUDENT = 'Student',
}

export interface User {
    id: string;
    name: string;
    avatarUrl: string;
    role: UserRole;
    club?: string;
}

export enum NoticeCategory {
    GENERAL = 'General',
    ACADEMICS = 'Academics',
    CLUB = 'Club Activities',
    PLACEMENTS = 'Placements',
    SPORTS = 'Sports',
    TECH = 'Tech Events',
    NON_TECH = 'Non-Tech Events',
    COLLEGE = 'College Fest',
}

export interface Organizer {
    name: string;
    avatarUrl: string;
}

export interface Recruitment {
    title: string;
    description: string;
    roles: string[];
}

export interface Notice {
    id: string;
    title: string;
    content: string;
    author: string;
    date: string;
    category: NoticeCategory;
    isPinned: boolean;
    imageUrl?: string;
    organizers?: Organizer[];
    recruitment?: Recruitment;
}

export enum ChatChannel {
    GENERAL = 'general',
    ANNOUNCEMENTS = 'announcements',
    PROJECTS = 'projects',
    RANDOM = 'random',
}

export interface Message {
    id: string;
    sender: string;
    avatarUrl: string;
    message: string;
    timestamp: string;
    channel: ChatChannel;
}

export interface Subject {
    name: string;
    credits: number;
}

export interface Semester {
    id: string;
    name: string;
    subjects: Subject[];
}

export interface Branch {
    name: string;
    semesters: Semester[];
}

export interface QuickLink {
    name: string;
    url: string;
}

export interface Job {
    id: string;
    title: string;
    company: string;
    logoUrl: string;
    location: string;
    salary: string;
    type: 'Full-time' | 'Internship';
    description: string;
}

export interface Achievement {
    id: string;
    studentName: string;
    avatarUrl: string;
    achievement: string;
    competition: string;
    date: string;
}

export interface GalleryImage {
    id: string;
    src: string;
    alt: string;
}

export interface ClubMember {
    name: string;
    role: 'President' | 'Member' | 'Coordinator';
    avatarUrl: string;
}

export interface ClubEvent {
    id: string;
    title: string;
    date: string;
    description: string;
}

export interface Club {
    id: string;
    name: string;
    description: string;
    longDescription: string;
    logoUrl: string;
    bannerUrl: string;
    category: 'Technical' | 'Non-Technical' | 'Cultural';
    members: ClubMember[];
    events: ClubEvent[];
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: string;
  coverArt: string;
}

export interface Playlist {
  id: string;
  name: string;
  coverArt: string;
  trackCount: number;
}

export interface CareerResource {
    id: string;
    title: string;
    type: 'Article' | 'Video' | 'Webinar';
    author: string;
    summary: string;
    thumbnailUrl: string;
    url: string;
}

export interface CareerPath {
    id: string;
    title: string;
    description: string;
    relatedRoles: string[];
    skills: string[];
}